# AzdaNews Beta 1.0

A Pen created on CodePen.

Original URL: [https://codepen.io/Arseniy-the-scripter/pen/QwyayjX](https://codepen.io/Arseniy-the-scripter/pen/QwyayjX).

